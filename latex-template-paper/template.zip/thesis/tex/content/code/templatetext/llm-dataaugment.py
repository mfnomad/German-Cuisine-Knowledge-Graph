def generate_row_prompt(row):
    beverage_name = row["BeverageName"]
    known_fields = {col: row[col] for col in columns_to_fill if pd.notna(row[col]) and row[col].strip() != ""}
    missing_fields = [col for col in columns_to_fill if col not in known_fields]

    prompt = (
        f"You are an expert in German Beverages. You will receive only the name of a beverage, "
        f"and your task is to fill in the missing fields. "
        f"Respond in English and don't use special german characters such as ä, ö, ü, ß. \n"
        "DO NOT add any additional information or context or comment.\n\n"
        f"BeverageName: {beverage_name}\n"
    )
    for key, value in known_fields.items():
        prompt += f"{key}: {value}\n"

    prompt += "\nNow fill in ONLY the missing fields with realistic and concise values. "
    prompt += "Return your answer as a valid JSON object with keys ONLY from this list:\n"
    prompt += f"{missing_fields}\n\n"
    prompt += (
        "Field Restrictions:\n"
        "- Description: Short beverage description, don't mention the word 'german' - String.\n"
        "- Region: Regions in Germany where the beverage is popular - can be multiple, can even include neighboring countries, "
        "don't mention the word 'Germany' - String.\n"
        "- MainIngredient: Single Main component - String.\n"
        "- Ingredients: comma-separated list - String.\n"
        "- FlavorProfiles: String list, comma-separated from "
        "['sweet', 'bitter', 'sour', 'fruity', 'malty', 'hoppy', 'herbal',"
        "'citrusy', 'spiced', 'floral', 'nutty', 'chocolaty', 'caramel-like',"
        "'yeasty', 'creamy', 'smooth', 'dry', 'refreshing', 'earthy'].\n"
        "- IsCarbonated: 'yes' or 'no' - String.\n"
        "- AlcoholContent: Alcohol by volume percentage - Float.\n"
        "- BeverageType: Type of beverage e.g. beer, wine, soda, juice, coffee - String.\n"
        "- ServingTemperature: Serving temperature, e.g., 'chilled', 'room temperature', 'hot' - String.\n"
        "- IsGermanStaple: 'yes' if culturally significant, otherwise 'no' - String.\n"
    )
    return prompt