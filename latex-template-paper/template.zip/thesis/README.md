This folder contains the 'tex' folder with one maintained LaTeX template for your thesis with a lot of useful hints for writing with LaTeX and wirting in general. 
Additionally, it contains a folder for a Word Template. This Word Template is not well maintained, but derived from the LaTeX Template.
Hence, it still contains a lot of LaTeX tips, but also the same tips for general writing.

If you use the Word template, please search the complete document for writing tips and adjust the template as you need. It contains all relevant parts, such as Headline Styles, Title Page, or Lists of Figures, Tables, ... Make sure to use a Tool for your references and do not do that manually!!

