# Struktur Proposal

* Einleitung / Introduction:
Motivation und allgemeine Einleitung zum Thema.

* (Technischer) Hintergrund / Background:
Welche Technologien verwendet ihr und wie funktionieren diese.

* Stand der Wissenschaft / Related Work:
Gruppieren, zusammenfassen und abgrenzen von anderen Arbeiten in dem
Feld der Arbeit

* Entwurf / Design:
Beschreibung der geplanten Umsetzung

* Auswertung / Evaluation:
Beschreibung der geplanten Auswertungen und Herangehensweise

* Zeitplan / Schedule:
Grober Zeitplan für die nächsten 6 Monate 